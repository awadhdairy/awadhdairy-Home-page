/* =========================================================
   Awadh Dairy: client script
   No frameworks, no build step, no tracking.
   ========================================================= */
(() => {
  "use strict";

  /* ---------- Site settings: edit these ---------- */
  const CONFIG = {
    whatsapp: "919450930971",              // country code + number, digits only
    phone: "+91 94509 30971",              // shown on the contact section
    email: "mail@awadhdairy.com",
    prices: { cow: null, buffalo: null }   // e.g. { cow: "₹60 / litre" }. null shows "Price on request"
  };

  const root = document.documentElement;
  root.classList.add("js");

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const finePointer = window.matchMedia("(pointer: fine)").matches;
  const stacked = window.matchMedia("(max-width: 960px)");

  const waBase = `https://wa.me/${CONFIG.whatsapp}`;

  /* ---------- Fill config-driven content ---------- */
  document.querySelectorAll("[data-price]").forEach((el) => {
    el.textContent = CONFIG.prices[el.dataset.price] || "Price on request";
  });
  document.querySelectorAll("[data-phone]").forEach((el) => {
    el.textContent = CONFIG.phone;
  });
  document.querySelectorAll("[data-tel]").forEach((el) => {
    el.href = `tel:+${CONFIG.whatsapp}`;
    el.textContent = CONFIG.phone;
  });
  document.querySelectorAll("[data-wa-link]").forEach((el) => {
    el.href = waBase;
  });

  const yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ---------- Split headlines into words for the mask reveal ---------- */
  document.querySelectorAll(".split").forEach((el) => {
    const words = el.textContent.trim().split(/\s+/);
    el.textContent = "";
    words.forEach((word, i) => {
      const wrap = document.createElement("span");
      wrap.className = "w";
      const inner = document.createElement("span");
      inner.textContent = word;
      inner.style.setProperty("--i", i);
      wrap.appendChild(inner);
      el.appendChild(wrap);
      if (i < words.length - 1) el.appendChild(document.createTextNode(" "));
    });
  });

  /* ---------- Stagger children of grids ---------- */
  document.querySelectorAll(".grid, .form__grid").forEach((grid) => {
    [...grid.children].forEach((child, i) => {
      if (!child.style.getPropertyValue("--d")) {
        child.style.setProperty("--d", `${i * 0.1}s`);
      }
    });
  });

  /* ---------- Counters ---------- */
  const counters = document.querySelectorAll("[data-count]");

  function animateCount(el) {
    const target = Number(el.dataset.count);
    const suffix = el.dataset.suffix || "";
    const duration = 1800;
    const start = performance.now();

    const tick = (now) => {
      const t = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - t, 3);
      el.textContent = `${Math.round(target * eased)}${suffix}`;
      if (t < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }

  /* ---------- Scroll reveals (one observer for reveals, headlines and counters) ---------- */
  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (!entry.isIntersecting) return;
        const el = entry.target;
        el.classList.add("in");
        if (el.hasAttribute("data-count") && !reduceMotion) animateCount(el);
        io.unobserve(el);
      });
    },
    { threshold: 0.15, rootMargin: "0px 0px -8% 0px" }
  );

  document.querySelectorAll(".reveal, .split, [data-count]").forEach((el) => io.observe(el));

  if (reduceMotion) {
    document.querySelectorAll(".reveal, .split").forEach((el) => el.classList.add("in"));
  }

  /* ---------- Hero bottle fills once the page has loaded ---------- */
  const heroBottle = document.querySelector(".bottle--hero");
  if (heroBottle && !reduceMotion) {
    window.setTimeout(() => heroBottle.style.setProperty("--fill", "0.86"), 500);
  } else if (heroBottle) {
    heroBottle.style.setProperty("--fill", "0.86");
  }

  /* ---------- Scroll-linked effects (one rAF loop, passive listener) ---------- */
  const progress = document.querySelector(".progress");
  const nav = document.querySelector(".nav");
  const heroScene = document.querySelector(".hero__scene");
  const orbs = document.querySelectorAll(".orb");
  const journey = document.getElementById("journey");
  const journeyBottle = document.querySelector(".bottle--journey");
  const stages = document.querySelectorAll(".stage");
  const railDots = document.querySelectorAll(".rail__dot");
  let ticking = false;

  function updateJourney() {
    if (!journey || stacked.matches) return;

    const rect = journey.getBoundingClientRect();
    const total = journey.offsetHeight - window.innerHeight;
    const p = Math.min(Math.max(-rect.top / total, 0), 1);

    journey.style.setProperty("--j", p.toFixed(4));

    if (journeyBottle) {
      journeyBottle.style.setProperty("--fill", (0.04 + p * 0.96).toFixed(3));
    }

    const active = Math.min(stages.length - 1, Math.floor(p * stages.length));
    stages.forEach((s, i) => s.classList.toggle("is-active", i === active));
    railDots.forEach((d, i) => d.classList.toggle("is-on", i <= active));
  }

  function onScroll() {
    const y = window.scrollY;
    const max = document.documentElement.scrollHeight - window.innerHeight;

    if (progress) progress.style.setProperty("--p", max > 0 ? (y / max).toFixed(4) : "0");
    if (nav) nav.classList.toggle("scrolled", y > 8);

    if (!reduceMotion) {
      if (heroScene) {
        heroScene.style.setProperty("--scroll", Math.min(y / window.innerHeight, 1).toFixed(4));
      }
      orbs.forEach((orb) => {
        orb.style.setProperty("--py", (y * Number(orb.dataset.speed || 0)).toFixed(1));
      });
      updateJourney();
    }

    ticking = false;
  }

  window.addEventListener(
    "scroll",
    () => {
      if (!ticking) {
        ticking = true;
        requestAnimationFrame(onScroll);
      }
    },
    { passive: true }
  );
  window.addEventListener("resize", onScroll, { passive: true });
  onScroll();

  /* ---------- Pointer effects (mouse only, skipped for reduced motion) ---------- */
  if (finePointer && !reduceMotion) {

    /* Soft glow that follows the cursor, eased with lerp */
    const glow = document.querySelector(".cursor-glow");
    if (glow) {
      let gx = 0, gy = 0, tx = 0, ty = 0, raf = false;
      const loop = () => {
        gx += (tx - gx) * 0.14;
        gy += (ty - gy) * 0.14;
        glow.style.transform = `translate3d(${gx}px, ${gy}px, 0)`;
        raf = Math.abs(tx - gx) > 0.5 || Math.abs(ty - gy) > 0.5;
        if (raf) requestAnimationFrame(loop);
      };
      window.addEventListener("pointermove", (e) => {
        tx = e.clientX;
        ty = e.clientY;
        glow.classList.add("on");
        if (!raf) {
          raf = true;
          requestAnimationFrame(loop);
        }
      }, { passive: true });
    }

    /* Cards: 3D tilt and a glare that follows the pointer */
    document.querySelectorAll(".tilt").forEach((el) => {
      el.addEventListener("pointermove", (e) => {
        const r = el.getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width;
        const py = (e.clientY - r.top) / r.height;
        el.style.setProperty("--mx", `${(px * 100).toFixed(1)}%`);
        el.style.setProperty("--my", `${(py * 100).toFixed(1)}%`);
        el.style.transform =
          `perspective(1000px) rotateX(${((0.5 - py) * 9).toFixed(2)}deg) rotateY(${((px - 0.5) * 11).toFixed(2)}deg) translate3d(0, -6px, 0)`;
      });
      el.addEventListener("pointerleave", () => {
        el.style.transform = "";
      });
    });

    /* Hero bottle leans toward the cursor */
    const heroTarget = document.querySelector("[data-tilt-hero]");
    if (heroScene && heroTarget) {
      heroScene.addEventListener("pointermove", (e) => {
        const r = heroScene.getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width - 0.5;
        const py = (e.clientY - r.top) / r.height - 0.5;
        heroTarget.style.transform =
          `perspective(900px) rotateX(${(-py * 14).toFixed(2)}deg) rotateY(${(px * 18).toFixed(2)}deg) translate3d(${(px * 14).toFixed(1)}px, ${(py * 10).toFixed(1)}px, 0)`;
      });
      heroScene.addEventListener("pointerleave", () => {
        heroTarget.style.transform = "";
      });
    }

    /* Magnetic buttons: they lean toward the cursor when it gets close */
    document.querySelectorAll(".magnetic").forEach((el) => {
      el.addEventListener("pointermove", (e) => {
        const r = el.getBoundingClientRect();
        const dx = e.clientX - (r.left + r.width / 2);
        const dy = e.clientY - (r.top + r.height / 2);
        el.style.transform = `translate3d(${(dx * 0.22).toFixed(1)}px, ${(dy * 0.32).toFixed(1)}px, 0)`;
      });
      el.addEventListener("pointerleave", () => {
        el.style.transform = "";
      });
    });
  }

  /* ---------- Mobile menu ---------- */
  const toggle = document.querySelector(".nav__toggle");
  const menu = document.getElementById("menu");

  if (toggle && menu) {
    toggle.addEventListener("click", () => {
      const open = menu.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
      toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    });

    menu.addEventListener("click", (e) => {
      if (e.target instanceof HTMLAnchorElement) {
        menu.classList.remove("open");
        toggle.setAttribute("aria-expanded", "false");
        toggle.setAttribute("aria-label", "Open menu");
      }
    });
  }

  /* ---------- Subscription form (opens WhatsApp, no backend) ---------- */
  const form = document.getElementById("subscribe-form");
  if (form) {
    const labels = { cow: "Cow milk", buffalo: "Buffalo milk", both: "Cow and buffalo" };
    const status = form.querySelector(".form__status");
    const startInput = form.elements.start;

    const todayISO = () => {
      const d = new Date();
      d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
      return d.toISOString().slice(0, 10);
    };
    startInput.min = todayISO();

    // Product cards preselect the milk in the form
    document.querySelectorAll("[data-product]").forEach((btn) => {
      btn.addEventListener("click", () => {
        form.elements.milk.value = btn.dataset.product;
      });
    });

    const setError = (name, message) => {
      const field = form.elements[name];
      const err = document.getElementById(`${name}-err`);
      if (field) field.setAttribute("aria-invalid", message ? "true" : "false");
      if (err) err.textContent = message || "";
    };

    form.addEventListener("submit", (e) => {
      e.preventDefault();

      const data = {
        name: form.elements.name.value.trim(),
        mobile: form.elements.mobile.value.replace(/\s+/g, ""),
        area: form.elements.area.value,
        milk: form.elements.milk.value,
        quantity: form.elements.quantity.value,
        start: form.elements.start.value,
        note: form.elements.note.value.trim()
      };

      const errors = {
        name: data.name.length < 2 ? "Please enter your name." : "",
        mobile: /^[6-9]\d{9}$/.test(data.mobile) ? "" : "Enter a valid 10-digit mobile number.",
        area: data.area ? "" : "Choose Lucknow or Barabanki.",
        milk: data.milk ? "" : "Choose the milk you want."
      };

      let firstInvalid = null;
      Object.entries(errors).forEach(([name, message]) => {
        setError(name, message);
        if (message && !firstInvalid) firstInvalid = form.elements[name];
      });

      if (firstInvalid) {
        status.textContent = "Please fix the highlighted fields.";
        firstInvalid.focus();
        return;
      }

      const lines = [
        "Hello Awadh Dairy, I would like to subscribe.",
        `Name: ${data.name}`,
        `Mobile: ${data.mobile}`,
        `Area: ${data.area}`,
        `Milk: ${labels[data.milk]}`,
        `Quantity: ${data.quantity} per day`,
        `Start date: ${data.start || "as soon as possible"}`,
        data.note ? `Note: ${data.note}` : null
      ].filter(Boolean);

      window.open(`${waBase}?text=${encodeURIComponent(lines.join("\n"))}`, "_blank", "noopener");

      status.textContent = "WhatsApp is opening with your details. Tap send to confirm.";
      form.reset();
      startInput.min = todayISO();
      ["name", "mobile", "area", "milk"].forEach((n) => setError(n, ""));
    });

    // Clear an error as soon as the customer fixes that field
    form.addEventListener("input", (e) => {
      if (e.target.getAttribute("aria-invalid") === "true") setError(e.target.name, "");
    });
  }
})();
