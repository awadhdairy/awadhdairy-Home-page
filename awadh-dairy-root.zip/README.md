# Awadh Dairy website

A static site made of plain HTML, CSS and JavaScript. There is no build step and no framework, so it loads fast and deploys straight to Cloudflare Pages.

## Files (must sit at the root of the repo or upload folder)

```
index.html        Homepage, SEO tags, structured data (LocalBusiness and FAQ)
css/styles.css    Design system: neumorphic and clay surfaces, glass bottles, motion
js/main.js        Settings (CONFIG), scroll and hover effects, WhatsApp form
robots.txt        Search engine rules
sitemap.xml       Sitemap for Google and Bing
_headers          Cloudflare security headers and caching rules
README.md         This file
```

Important: `index.html` must be at the top level, not inside a folder. If it sits one folder deep, Cloudflare returns a 404 for the homepage.

## Already set in this build

- WhatsApp and phone: +91 94509 30971 (WhatsApp number `919450930971`)
- Email: mail@awadhdairy.com
- Delivery: Lucknow and Barabanki only
- Payment: UPI, cash, debit and credit cards, bank transfer
- Bottle exchange: customers hand back empty glass bottles and take new ones

## Step 1: Set prices (optional, do it any time)

Open `js/main.js` and edit the `prices` line in CONFIG:

```js
prices: { cow: "₹60 / litre", buffalo: "₹70 / litre" }
```

Leave the values as `null` to keep showing "Price on request".

## Step 2A: Deploy from GitHub (recommended, auto-updates on every push)

1. Create a new repository on GitHub, for example `awadh-dairy`.
2. Extract `awadh-dairy-root.zip` and upload its contents to the repo root. Drag the files in, or use Git:

```bash
cd awadh-dairy
git init
git add .
git commit -m "Awadh Dairy website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/awadh-dairy.git
git push -u origin main
```

3. In Cloudflare, go to **Workers & Pages**, then **Create**, then **Pages**, then **Connect to Git**. Select the repo.
4. Build settings:
   - Framework preset: **None**
   - Build command: *(leave empty)*
   - Build output directory: `/`
5. Click **Save and Deploy**. The site goes live at `https://<project-name>.pages.dev` within a minute.

Each future `git push` redeploys automatically.

## Step 2B: Deploy without GitHub (direct upload)

1. In Cloudflare, go to **Workers & Pages**, then **Create**, then **Pages**, then **Upload assets**.
2. Name the project, for example `awadh-dairy`.
3. Upload the extracted contents of `awadh-dairy-root.zip`, or drag the folder in.
4. Click **Deploy**.

To update later, come back to the project and upload again.

## Step 3: Connect awadhdairy.com

1. Open your Pages project, then **Custom domains**, then **Set up a custom domain**.
2. Enter `awadhdairy.com`, then add `www.awadhdairy.com` as well.
3. If the domain's DNS is already on Cloudflare, the records are added for you. If not, add the CNAME records Cloudflare shows.
4. Wait for the status to show **Active**. Cloudflare issues the HTTPS certificate automatically.

## Step 4: Check after launch

- Open the site on a phone and a desktop. Check the hero bottle, the pinned journey section, the bottle exchange and the menu.
- Test the subscription form. It should open WhatsApp with the details filled in.
- Test the WhatsApp button and the email link.
- Run the page through Google PageSpeed Insights and the Rich Results Test.
- Add the site to Google Search Console and submit `https://awadhdairy.com/sitemap.xml`.
- Make sure `og-image.png` (1200 × 630) is at the site root, so WhatsApp and social previews show an image. Your current site already has this file; copy it into the repo if it is missing.

## Things to confirm before going live

These statements are written into the site. Confirm each one is true for your business, and change the text in `index.html` if not.

- **Process steps**: "Milk is handled carefully and kept cool from the moment it is collected" and "Poured into sealed glass bottles" are general descriptions. Confirm the chilling and bottling steps.
- **Pause, change or stop**: the site says customers can do this by WhatsApp.
- **Bottle exchange**: customers hand back empty glass bottles on each delivery and take new ones.
- **Payment methods**: UPI, cash, debit card, credit card and bank transfer. Remove any you do not accept.
- **Delivery time**: "before 8 AM" appears in several places. Update if your timing is different.
- **Delivery areas**: Lucknow and Barabanki only.
- **Address and map**: the map centres on coordinates 26.9126, 81.1838, taken from your existing site. Check the pin is at your farm.
- **Hindi lines**: a few Hindi phrases are included. Have a native speaker review them.
- **Photos**: the site uses illustrations of bottles and a farm. Real photos of the farm, cows and bottles build more trust. Add them as `.webp` files and reference them in `index.html`.
- **Testimonials**: none are included. Add real customer quotes once you have permission to use them.

## What makes it fast

- No JavaScript framework, no build step and no tracking scripts.
- All bottles and icons are inline SVG, so there are no image requests and everything stays sharp on any screen.
- Only Google Fonts load from outside, and the map loads lazily when you scroll near it.
- The site sets cache headers in `_headers`, so repeat visits load almost instantly.

## Motion and accessibility

- The hero bottle fills with milk, leans toward the cursor and floats gently.
- The "From the farm to your glass" section is pinned. Scroll through it to fill one bottle, from the farm to your door.
- Headlines split into words and rise into view. Counters count up.
- Buttons are magnetic on desktop and show a light sweep on hover. Cards tilt with a glare that follows the pointer.
- Everything is turned off for people who have "reduce motion" enabled in their phone or computer settings. The page still reads and works fully.
- The site works without JavaScript. Content stays visible, only the motion is skipped.
- Touch devices skip the cursor effects and keep the scroll effects.

## Editing tips

- Change text: edit `index.html`.
- Change colours and sizes: edit the variables at the top of `css/styles.css`.
- Change the WhatsApp number, prices or email: edit the CONFIG block at the top of `js/main.js`.
